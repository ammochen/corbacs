// distdate.hh -- Automatically generated file

#define OMNIORB_DIST_DATE "Sun Jul 19 18:35:23 BST 2009 dgrisby"
